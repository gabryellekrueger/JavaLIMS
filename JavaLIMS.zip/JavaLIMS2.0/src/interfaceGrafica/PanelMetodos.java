package interfaceGrafica;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelMetodos extends JPanel {

	/**
	 * Create the panel.
	 */
	public PanelMetodos() {

		setBounds(275, 150, 1305, 730);
		setVisible(true);
		setBackground(new Color(213, 239, 236));
		setLayout(null);
		
		JLabel lblTeste = new JLabel("METODOS");
		lblTeste.setBounds(100, 100, 100, 100);
		add(lblTeste);

	}

}
